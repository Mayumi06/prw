<!DOCTYPE html>
<html lang = "en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv = "X-UA-Compatible" content="IE=edge">
        <meta name = "viewport" content = "width=device-width, initial-scale=1"> 
        <title>Menu Principal</title>
        <link rel= "stylesheet" href="estilo.css">
    </head>

    <body>
        <h1>Menu Principal</h1>
        <div id ="menu">
            <ul>
                <li><a href="cadastro_agenda.html">Cadastrar Agenda</a></li>
                <li><a href="listar_agenda.php">Listar Agenda</a></li>
            </ul>
        </div>
    </body>
    </head>
</html>